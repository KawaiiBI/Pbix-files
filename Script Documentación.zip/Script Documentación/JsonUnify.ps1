﻿# Título: Unir múltiples archivos JSON en uno solo
# Descripción: Este script combina todos los archivos JSON de una carpeta en un único archivo JSON.

param (
    [alias("j")]
    [string]$jsonFolderPath  # Ruta principal de la carpeta output
)
# Ruta donde se encuentran los archivos JSON
$outputFilePath = Join-Path -Path $jsonFolderPath -ChildPath "unidos.json" # Ruta y nombre del archivo combinado

Write-Output "Leyendo archivos JSON desde: $jsonFolderPath"

# Validar si la carpeta de JSON existe
if (-not (Test-Path -Path $jsonFolderPath)) {
    Write-Error "La ruta $jsonFolderPath no existe. Verifica la ruta."
    exit
}

# Obtener todos los archivos JSON en la carpeta
$jsonFiles = Get-ChildItem -Path $jsonFolderPath -Filter "*.json"
if (-not $jsonFiles) {
    Write-Error "No se encontraron archivos JSON en $jsonFolderPath. Asegúrate de que haya archivos."
    exit
}

Write-Output "Archivos JSON encontrados: $($jsonFiles.Count)"

# Crear una lista para almacenar los datos combinados
$combinedJson = @()

foreach ($jsonFile in $jsonFiles) {
    Write-Output "Procesando archivo: $($jsonFile.Name)"
    try {
        # Leer el contenido del archivo JSON con codificación UTF-8
        $jsonContent = Get-Content -Path $jsonFile.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
        # Agregar el contenido al JSON combinado
        $combinedJson += $jsonContent
    } catch {
        Write-Error "Error procesando el archivo $($jsonFile.Name): $_"
    }
}

# Convertir los datos combinados a formato JSON
$finalJson = $combinedJson | ConvertTo-Json -Depth 10 -Compress

# Guardar el JSON combinado en el archivo de salida con codificación UTF-8
try {
    Out-File -FilePath $outputFilePath -Encoding UTF8 -Force -InputObject $finalJson
    Write-Output "Archivo JSON combinado creado exitosamente: $outputFilePath"
} catch {
    Write-Error "Error al guardar el archivo combinado: $_"
}


& ".\WordGeneration.ps1" -jsonPath $outputFilePath