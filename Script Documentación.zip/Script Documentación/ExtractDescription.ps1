﻿# Título: Extraer JSONs desde "tables" partiendo de la carpeta "documentación"
# Descripción: Recorre desde la carpeta "documentación", encuentra "tables" y extrae los JSON de tablas y medidas.
param (
    [alias("rutaJson")]
    [string]$documentationPath,  # Ruta principal de la carpeta "documentación"
    [alias("rutaSalida")]
    [string]$outputPath          # Carpeta de destino donde guardar los JSON
)

Write-Output "Ruta base: $documentationPath"
Write-Output "Ruta de salida: $outputPath"

# Validar si la carpeta documentación existe
if (-not (Test-Path -Path $documentationPath)) {
    Write-Error "La ruta base $documentationPath no existe. Verifica la ruta."
    exit
}

# Buscar la carpeta "tables" dentro de "documentación"
$tablesPath = Join-Path -Path $documentationPath -ChildPath "tables"
if (-not (Test-Path -Path $tablesPath)) {
    Write-Error "No se encontró la carpeta 'tables' dentro de $documentationPath. Verifica la estructura."
    exit
}

Write-Output "Carpeta 'tables' encontrada en: $tablesPath"

# Crear el directorio de salida si no existe
if (-not (Test-Path -Path $outputPath)) {
    Write-Output "Creando directorio de salida: $outputPath"
    New-Item -ItemType Directory -Path $outputPath | Out-Null
}

# Obtener todas las carpetas dentro de "tables"
$folders = Get-ChildItem -Path $tablesPath -Directory
if (-not $folders) {
    Write-Error "No se encontraron carpetas dentro de $tablesPath. Verifica que la ruta contiene subcarpetas."
    exit
}

Write-Output "Carpetas encontradas: $($folders.Count)"

foreach ($folder in $folders) {
    # Nombre de la carpeta actual (tabla)
    $tableName = $folder.Name
    Write-Output "Procesando carpeta: ${tableName}"

    # Listar los archivos dentro de la carpeta actual
    $allFiles = Get-ChildItem -Path $folder.FullName -File
    if (-not $allFiles) {
        Write-Output "No se encontraron archivos en la carpeta: ${tableName}"
        continue
    }

    # Mostrar todos los archivos encontrados (para verificar)
    Write-Output "Archivos encontrados en ${tableName}:"
    $allFiles | ForEach-Object { Write-Output " - $($_.Name)" }

    # 1. Buscar el archivo JSON que coincide con el nombre de la carpeta
    $tableJson = $allFiles | Where-Object { $_.Name -eq "$tableName.json" }

    if ($tableJson) {
        # Copiar el archivo JSON al directorio de destino
        Write-Output "Encontrado archivo JSON de tabla: $($tableJson.Name)"
        Copy-Item -Path $tableJson.FullName -Destination $outputPath -Force
    } else {
        Write-Output "No se encontró archivo JSON de tabla en: ${tableName}"
    }

    # 2. Buscar la subcarpeta "measures" dentro de la carpeta actual
    $measuresFolder = Get-ChildItem -Path $folder.FullName -Directory | Where-Object { $_.Name -eq "measures" }

    if ($measuresFolder) {
        Write-Output "Encontrada carpeta 'measures' en: ${tableName}"
        # Obtener todos los JSON dentro de la carpeta "measures"
        $measureJsons = Get-ChildItem -Path $measuresFolder.FullName -File | Where-Object { $_.Extension -eq ".json" }
        foreach ($measureJson in $measureJsons) {
            # Copiar cada archivo JSON de medidas al directorio de destino
            Write-Output "Encontrado archivo JSON de medida: $($measureJson.Name)"
            Copy-Item -Path $measureJson.FullName -Destination $outputPath -Force
        }
    } else {
        Write-Output "No se encontró carpeta 'measures' en: ${tableName}"
    }
}

Write-Output "Proceso completado. Los archivos JSON están en: $outputPath"

& ".\JsonUnify.ps1" -jsonFolderPath $outputPath