﻿param (
    [alias("j")]
    [string]$jsonPath  # Ruta principal de la carpeta "documentación"
)

# Leer el contenido del JSON
$jsonContent = Get-Content -Path $jsonPath -Raw | ConvertFrom-Json

# Ruta para guardar el documento Word
$outputWord = [string](Join-Path -Path (Split-Path -Path $jsonPath -Parent) -ChildPath "documento_descripciones.docx")

# Crear un objeto Word
$wordApp = New-Object -ComObject Word.Application
$wordApp.Visible = $false
$doc = $wordApp.Documents.Add()


# Función para agregar texto con formato
function Add-Text {
    param (
        [string]$text
    )
    $selection = $wordApp.Selection
    $selection.TypeText($text)
    $selection.TypeParagraph()

}

# Agregar título del documento
Add-Text "Descripciones de Tablas y Medidas" "Título 1"

# Iterar por cada elemento del JSON
foreach ($item in $jsonContent) {
    # Obtener el título y descripción
    $name = $item.name
    $description = $item.description -join " "  # Unir descripciones que están como array

    # Agregar el nombre como título
    Add-Text $name "Título 2"

    # Agregar la descripción como texto normal
    if ($description) {
        Add-Text $description "Normal"
    } else {
        Add-Text "Sin descripción disponible." "Normal"
    }
}

# Guardar el documento
$doc.SaveAs([ref]$outputWord)
$doc.Close()
$wordApp.Quit()

# Liberar recursos
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($wordApp) | Out-Null
Write-Host "Documento generado en: $outputWord"

# Obtener el directorio de $outputWord
$outputDirectory = Split-Path -Path $outputWord -Parent

# Eliminar todos los archivos .json en el directorio
try {
    Get-ChildItem -Path $outputDirectory -Filter "*.json" | ForEach-Object {
        Remove-Item -Path $_.FullName -Force
    }
    Write-Output "Todos los archivos .json han sido eliminados del directorio: $outputDirectory"
} catch {
    Write-Error "Error al eliminar los archivos .json: $_"
}